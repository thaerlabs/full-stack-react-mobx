import {Router} from 'express';
import models from "../config/sequelize";

const router = Router();

router.use('/user', require('./user'));
router.use('/role', require('./role'));
router.use('/menu', require('./menu_item'));
router.use('/auth', require('./auth'));
router.use('/hotel', require('./hotel'));
router.get('/cities/search', (req, res, next) => {

  const { q } = req.query;

  let cities = [];

  if (q && q.length > 2) {
    cities = models.sequelize
      .query('SELECT DISTINCT `City` FROM `activepropertylist` AS `activepropertylist` WHERE `City` LIKE "%' + q + '%" ORDER BY `activepropertylist`.`City` ASC', {
        type: models.sequelize.QueryTypes.SELECT
      })
      .then((data) => {

        cities = data.map((city) => {
          return {
            name: city.City,
            value: city.City
          };
        });

        res.send({
          success: true,
          results: cities
        });
      })
  } else {
    res.send({
      success: true,
      results: cities
    });
  }

});

module.exports = router;
