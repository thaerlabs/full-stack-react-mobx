import {Router} from 'express';
import {create , list } from './user.controller';
import {isAuthenticated} from '../../middleware/auth.middleware';

const router = Router();

router.use(isAuthenticated);

router.get('/', list);
router.post('/', create);

module.exports = router;
