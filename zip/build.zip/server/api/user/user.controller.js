import User from '../../mongoose_models/User';
import Boom from 'Boom';
import bluebird from 'bluebird';

/**
 * Create new user
 * @param req
 * @param res
 * @param next
 */
export function create(req, res, next) {
  var user = new User(req.body);
  user.password = req.body.password;
  user.passwordConfirmation = req.body.passwordVerify;

  bluebird.coroutine(function *() {
    var newUser = yield user.save();
    res.send(newUser);
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}

/**
 * List all users
 * @param req
 * @param res
 * @param next
 */
export function list(req, res, next) {
  bluebird.coroutine(function *() {
    var users = yield User
      .find({}, '_id username FirstName LastName role')
      .populate('role', '_id name');

    res.json(users);
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}
