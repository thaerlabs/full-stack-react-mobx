import {Router} from 'express';
import {create , list, addMenuItem, removeMenuItem } from './role.controller';
import {isAuthenticated} from '../../middleware/auth.middleware';

const router = Router();

router.use(isAuthenticated);

router.get('/', list);
router.post('/', create);
router.put('/:id/menu/:itemId', addMenuItem);
router.delete('/:id/menu/:itemId', removeMenuItem);

module.exports = router;
