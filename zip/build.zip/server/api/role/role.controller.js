import Role from '../../mongoose_models/Role';
import Boom from 'Boom';
import bluebird from 'bluebird';

/**
 * Create new role
 * @param req
 * @param res
 * @param next
 */
export function create(req, res, next) {

  bluebird.coroutine(function *() {
    var role = yield new Role(req.body).save();
    res.send(role);
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}

/**
 * Return list of all existing roles
 * @param req
 * @param res
 * @param next
 */
export function list(req, res, next) {

  bluebird.coroutine(function *() {
    var roles = yield Role.find({}, '_id name menuItems').populate('menuItems', '_id name');
    res.send(roles);
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}

/**
 * Add new menu item for specific role
 * @param req
 * @param res
 * @param next
 */
export function addMenuItem(req, res, next) {

  bluebird.coroutine(function *() {
    yield Role.update({_id: req.params.id}, {$push: {'menuItems': req.params.itemId}});


    var role = yield Role.findOne({_id: req.params.id}).populate('menuItems', '_id name');
    res.send(role);
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}

/**
 * Remove menu item from specific role
 * @param req
 * @param res
 * @param next
 */
export function removeMenuItem(req, res, next) {

  bluebird.coroutine(function *() {
    yield Role.update({_id: req.params.id}, {$pull: {'menuItems': req.params.itemId}});

    var role = yield Role.find({_id: req.params.id}).populate('menuItems', '_id name');
    res.send(role);
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}
