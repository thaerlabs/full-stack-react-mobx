import {Router} from 'express';
import {getHotel, getHotels, getHotelVersion, saveHotelDraft, publishHotel} from './hotel.controller';
import {isAuthenticated} from '../../middleware/auth.middleware';

const router = Router();

//router.use(isAuthenticated);
router.get('/', getHotels);
router.get('/:id', getHotel);
router.get('/version/:versionId', getHotelVersion);
router.post('/draft', saveHotelDraft);
router.post('/publish', publishHotel);

module.exports = router;
