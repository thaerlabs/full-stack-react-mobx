import HotelDraft from "../../mongoose_models/Hotel_Draft";
import HotelPublish from "../../mongoose_models/Hotel_Publish";
import HotelArchive from "../../mongoose_models/Hotel_Archive";
import bluebird from "bluebird";
import Boom from "Boom";
import _ from "lodash";
import models from "../../config/sequelize";
import async from "async";

/**
 * Return hotel list
 * @param req
 * @param res
 * @param next
 */

/**
 * TODO
 * 1. Keep one res.send at the bottom
 * 2. Polish the controller and abstract the different suources with a model container
 *    to be able to fetch more simply
 * 3. Try to make different queries in parallel
 */
export function getHotels(req, res, next) {
  var query = req.query;
  var offset = _.get(query, 'offset', 0);
  var limit = _.get(query, 'limit', 25);
  var searchText = _.get(query, 'search');
  var city = _.get(query, 'city');

  bluebird.coroutine(function *() {
    var condition = {};
    var toReturn = [];

    /**
     * Fetch published hotels
     */
    if (query.publish === "1") {
      if (!_.isUndefined(searchText)) {
        condition['hotel_en.Name'] = new RegExp(searchText, "i")
      }

      if (!_.isUndefined(city)) {
        condition['hotel_en.City'] = new RegExp(city, "i")
      }

      let hotelCount = yield HotelPublish.count({});
      let hotels = yield HotelPublish.find(condition)
        .limit(_.parseInt(limit))
        .skip(_.parseInt(offset))
        .populate({
          path: 'versionDoc',
          select: '_id EANHotelID version is_synced createdAt updatedAt',
          options: {sort: {'createdAt': -1}}
        })
        .exec();

      async.forEach(hotels, function (hotel, cb) {
        var temp = {
          EANHotelID: hotel.EANHotelID,
          Name: hotel.hotel_en.Name,
          City: hotel.hotel_en.City,
          version: hotel.version,
          is_synced: hotel.is_synced,
          is_published: true,
          versionDoc: hotel.versionDoc
        };
        HotelDraft.findOne({EANHotelID: hotel.EANHotelID})
          .then((draftHotel) => {
            temp["is_draft"] = draftHotel !== null;
            toReturn.push(temp);
            cb();
          })
          .catch((err)=> {
            toReturn.push(temp);
            cb();
          });
      }, function (err, result) {
        res.send({
          hotels: toReturn,
          totalHotels: hotelCount
        });
      })

    }
    /**
     * Fetch draft hotels
     */
    else if (query.draft === "1") {
      if (!_.isUndefined(searchText)) {
        condition['hotel_en.Name'] = new RegExp(searchText, "i")
      }

      if (!_.isUndefined(city)) {
        condition['hotel_en.City'] = new RegExp(city, "i")
      }

      let hotelCount = yield HotelDraft.count({});
      let hotels = yield HotelDraft.find(condition)
        .limit(_.parseInt(limit))
        .skip(_.parseInt(offset))
        .exec();

      async.forEach(hotels, function (hotel, cb) {
        var temp = {
          EANHotelID: hotel.EANHotelID,
          Name: hotel.hotel_en.Name,
          City: hotel.hotel_en.City,
          is_draft: true
        };
        HotelPublish.findOne({EANHotelID: hotel.EANHotelID})
          .then((publishHotel) => {
            if (publishHotel !== null) {
              temp["version"] = publishHotel.version;
              temp["is_synced"] = publishHotel.is_synced;
              temp["is_published"] = true;
              temp["versionDoc"] = publishHotel.versionDoc;
            }
            else {
              temp["is_published"] = false;
              temp["version"] = 0;
              temp["is_synced"] = false;
              temp["versionDoc"] = [];
            }
            toReturn.push(temp);
            cb();
          })
          .catch((err)=> {
            toReturn.push(temp);
            cb();
          });
      }, function (err, result) {
        res.send({
          hotels: toReturn,
          totalHotels: hotelCount
        });
      })

    }
    else {
      if (!_.isUndefined(searchText)) {
        condition['Name'] = {
          $like: '%' + searchText + '%'
        }
      }

      if (!_.isUndefined(city)) {
        condition['City'] = {
          $like: '%' + city + '%'
        }
      }

      /**
       * Fetch hotel list from mysql and count
       */
      var hotels = yield models.activepropertylist.findAll({where: condition, offset: _.parseInt(offset), limit: _.parseInt(limit)});
      var hotelCount = yield models.activepropertylist.count({where: condition});

      /**
       * Fetch hotel publish, sync status and versioning history
       */
      async.forEach(hotels, function (hotel, cb) {
        hotel = hotel.toJSON();

        HotelPublish.findOne({EANHotelID: hotel.EANHotelID})
          .populate('versionDoc', '_id EANHotelID version is_synced createdAt updatedAt')
          .exec()
          .then((publishedHotel) => {

            if (publishedHotel !== null) {
              hotel["version"] = publishedHotel.version;
              hotel["is_synced"] = publishedHotel.is_synced;
              hotel["is_published"] = true;
              hotel["versionDoc"] = publishedHotel.versionDoc;
            }
            else {
              hotel["is_published"] = false;
              hotel["version"] = 0;
              hotel["is_synced"] = false;
              hotel["versionDoc"] = [];
            }

            return HotelDraft.findOne({EANHotelID: hotel.EANHotelID});
          })
          .then((draftHotel) => {
            hotel["is_draft"] = draftHotel !== null;
            toReturn.push(hotel);
            cb();
          })
          .catch((err) => {
            toReturn.push(hotel);
            cb();
          });
      }, function (err, results) {
        res.send({
          hotels: toReturn,
          totalHotels: hotelCount
        });
      });
    }

  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}

/**
 * Get hotel details
 * @param req
 * @param res
 * @param next
 */
export function getHotel(req, res, next) {
  var condition = {EANHotelID: _.parseInt(req.params.id)};

  bluebird.coroutine(function *() {
    var hotelEn = {};
    var hotelAr = {};
    let additionalData = {};

    /**
     * Try to get hotel from draft collection
     */
    var hotel = yield HotelDraft.findOne(condition);

    if (hotel) {
      additionalData.status = 'draft';
      let publishedHotel = yield HotelPublish.findOne(condition)
        .populate({
          path: 'versionDoc',
          select: '_id EANHotelID version is_synced createdAt updatedAt',
          options: { sort: { 'createdAt': -1 } }
        })
        .exec();

      if (publishedHotel) {
        additionalData.publishedAt = publishedHotel.updatedAt;
        additionalData.version = publishedHotel.version;
        additionalData.is_synced = publishedHotel.is_synced;
        additionalData.is_published = true;
        additionalData.versionDoc = publishedHotel.versionDoc;
      }
    }

    /**
     * if not in draft, get from Published collection
     */
    if (!hotel) {
      hotel = yield HotelPublish.findOne(condition)
        .populate({
          path: 'versionDoc',
          select: '_id EANHotelID version is_synced createdAt updatedAt',
          options: { sort: { 'createdAt': -1 } }
        })
        .exec();

      if (hotel) {
        additionalData.status = 'published';
        additionalData.publishedAt = hotel.updatedAt;
        additionalData.version = hotel.version;
        additionalData.is_synced = hotel.is_synced;
        additionalData.is_published = true;
        additionalData.versionDoc = hotel.versionDoc;
      }
    }

    /**
     * if not in publish then get hotel details from mysql
     */
    if (!hotel) {
      hotel = yield models.activepropertylist.find({
        include: [
          {
            model: models.activepropertylist_ar_sa
          },
          {
            model: models.propertydescriptionlist
          },
          {
            model: models.propertydescriptionlist_ar_sa
          },
          {
            model: models.hotelimagelist
          }
        ],
        where: condition
      });

      additionalData.status = 'original';

      var fields = ['EANHotelID', 'Name', 'Address1', 'Address2', 'City', 'StateProvince', 'Country', 'Latitude', 'Longitude', 'Location', 'propertydescriptionlist', 'hotelimagelists'];
      hotelEn = _.pick(hotel, fields);
      hotelAr = _.merge({}, hotelEn, hotel.activepropertylist_ar_sa ? hotel.activepropertylist_ar_sa.dataValues : {}, {propertydescriptionlist: hotel.propertydescriptionlist_ar_sa});
    }
    else{
      hotelEn = hotel['hotel_en'];
      hotelAr = hotel['hotel_ar'];
    }

    res.send({
      hotel_en: hotelEn,
      hotel_ar: hotelAr,
      ...additionalData
    });

  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}

export function getHotelVersion(req, res, next) {

  bluebird.coroutine(function* (){

    const { hotel_en, hotel_ar } = yield HotelArchive.findOne({
      _id: req.params.versionId
    });

    res.send({
      hotel_en,
      hotel_ar
    });

  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}

/**
 * Save hotel as draft
 * @param req
 * @param res
 * @param next
 */
export function saveHotelDraft(req, res, next) {
  var hotel = req.body;

  bluebird.coroutine(function *() {
    /**
     * Fetch existing draft
     */
    var existingHotelDarft = yield HotelDraft.findOne({EANHotelID: hotel.EANHotelID});

    /**
     * If existing draft does not exist create a new one
     */
    if (existingHotelDarft === null) {
      yield new HotelDraft(req.body).save();
    }
    /**
     * else update the existing draft
     */
    else {
      yield HotelDraft.update({EANHotelID: hotel.EANHotelID}, hotel);
    }

    res.send({
      message: "Hotel has been saved as draft."
    });
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}

/**
 * Publihs hotel
 * @param req
 * @param res
 * @param next
 */
export function publishHotel(req, res, next) {
  let hotel = req.body;
  let hotelEn = {};
  let hotelAr = {};
  let additionalData = {};

  bluebird.coroutine(function *() {
    /**
     * Remove draft version of hotel data
     */
    yield HotelDraft.remove({EANHotelID: hotel.EANHotelID});

    /**
     * Fetch hotel from publish collection
     */
    var hotelPublish = yield HotelPublish.findOne({EANHotelID: hotel.EANHotelID}, {_id: 0});

    if (hotelPublish === null) {
      /**
       * if not exist in publish collection create a new one
       */
      var newHotelPublish = new HotelPublish(hotel);
      yield newHotelPublish.save();
    }
    else {
      /**
       * if exist move hotel data to archive and publish new version
       */
      var hotelArchive = yield new HotelArchive(_.omit(hotelPublish.toJSON(), ['createdAt', 'updatedAt'])).save();

      if (hotelArchive !== null) {
        hotel = _.extend(hotelPublish, hotel);

        hotel.version++;
        hotel.versionDoc.push(hotelArchive._id);

        yield HotelPublish.update({EANHotelID: hotel.EANHotelID}, hotel);
      }
    }

    let h = yield HotelPublish.findOne({EANHotelID: hotel.EANHotelID})
      .populate({
        path: 'versionDoc',
        select: '_id EANHotelID version is_synced createdAt updatedAt',
        options: { sort: { 'createdAt': -1 } }
      })
      .exec();

    hotelEn = h['hotel_en'];
    hotelAr = h['hotel_ar'];

    if (h) {
      additionalData.status = 'published';

      additionalData.version = h.version;
      additionalData.is_synced = h.is_synced;
      additionalData.is_published = true;
      additionalData.versionDoc = h.versionDoc;
    }

    res.send({
      hotel_en: hotelEn,
      hotel_ar: hotelAr,
      ...additionalData
    });
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}
