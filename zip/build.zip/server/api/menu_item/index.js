import {Router} from 'express';
import {create , list } from './menu_item.controller';
import {isAuthenticated} from '../../middleware/auth.middleware';

const router = Router();

router.use(isAuthenticated);

router.get('/', list);
router.post('/', create);

module.exports = router;
