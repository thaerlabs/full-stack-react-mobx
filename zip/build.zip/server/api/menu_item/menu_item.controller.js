import MenuItem from '../../mongoose_models/Menu_Item';
import Boom from 'Boom';
import bluebird from 'bluebird';

/**
 * Add new menu item
 * @param req
 * @param res
 * @param next
 */
export function create(req, res, next) {

  bluebird.coroutine(function *() {
    var menuItem = yield new MenuItem(req.body).save();
    res.send(menuItem);
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}

/**
 * Remove menu item
 * @param req
 * @param res
 * @param next
 */
export function list(req, res, next) {

  bluebird.coroutine(function *() {
    var menuItems = yield MenuItem.find({}, '_id name');
    res.send(menuItems);
  })().catch(function (err) {
    if (err.isBoom) return next(err);
    else return next(Boom.wrap(err, 422));
  });
}
