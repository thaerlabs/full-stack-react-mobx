import fs from 'fs';
import path from 'path';
import Sequelize from 'sequelize';
import _ from 'lodash';
import config from 'nconf';

var db = {};

// create your instance of sequelize
var sequelize = new Sequelize(config.get('HOTEL_PIM_MYSQL_DATABASE'), config.get('HOTEL_PIM_MYSQL_USERNAME'), config.get('HOTEL_PIM_MYSQL_PASSWORD'), {
  host: config.get('HOTEL_PIM_MYSQL_HOST'),
  dialect: 'mysql',
  logging: function(str){
    if(config.get('NODE_ENV') === 'local'){
      console.log(str);
    }
  },
  define: {
    timestamps: false
  }
});


const modelDir = path.join(process.cwd(), 'server/sequelize_models');
// loop through all files in models directory ignoring hidden files and this file
fs.readdirSync(modelDir)
  .filter(function (file) {
    return (file.indexOf('.') !== 0) && (file !== 'index.js')
  })
  // import model files and save model names
  .forEach(function (file) {
    var model = sequelize.import(path.join(modelDir, file));
    db[model.name] = model;
  });

Object.keys(db).forEach(function (modelName) {
  if ("associate" in db[modelName]) {
    db[modelName].associate(db);
  }
});

sequelize
  .sync({force: false})
  .then(function () {
    console.log("Database synchronized");
  })
  .catch(function (err) {
    console.log(err);
  });


// assign the sequelize variables to the db object and returning the db.
module.exports = _.extend({
  sequelize: sequelize,
  Sequelize: Sequelize
}, db);
