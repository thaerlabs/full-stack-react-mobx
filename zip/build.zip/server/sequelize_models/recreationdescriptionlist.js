/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var recreationdescriptionlist = sequelize.define('recreationdescriptionlist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RecreationDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'recreationdescriptionlist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        recreationdescriptionlist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });
  
  return recreationdescriptionlist;
};
