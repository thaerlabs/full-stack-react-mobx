/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var activepropertylist = sequelize.define('activepropertylist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    SequenceNumber: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    Name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Address1: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Address2: {
      type: DataTypes.STRING,
      allowNull: true
    },
    City: {
      type: DataTypes.STRING,
      allowNull: true
    },
    StateProvince: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PostalCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Country: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Latitude: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    Longitude: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    AirportCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyCategory: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    PropertyCurrency: {
      type: DataTypes.STRING,
      allowNull: true
    },
    StarRating: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    Confidence: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    SupplierType: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Location: {
      type: DataTypes.STRING,
      allowNull: true
    },
    ChainCodeID: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'chainlist',
        key: 'ChainCodeID'
      }
    },
    RegionID: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    HighRate: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    LowRate: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    CheckInTime: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CheckOutTime: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'activepropertylist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        activepropertylist.hasOne(models.activepropertybusinessmodel, {foreignKey: 'EANHotelID'});
        activepropertylist.hasOne(models.activepropertybusinessmodel_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasOne(models.activepropertylist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.areaattractionslist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.areaattractionslist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.belongsTo(models.chainlist, {foreignKey: 'ChainCodeID'});
        activepropertylist.hasMany(models.diningdescriptionlist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.diningdescriptionlist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.hotelimagelist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.policydescriptionlist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.policydescriptionlist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyamenitieslist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyamenitieslist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyattributelink, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyattributelink_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertybusinessamenitieslist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertybusinessamenitieslist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasOne(models.propertydescriptionlist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasOne(models.propertydescriptionlist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyfeeslist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyfeeslist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertylocationlist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertylocationlist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertymandatoryfeeslist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertymandatoryfeeslist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertynationalratingslist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertynationalratingslist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyrenovationslist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyrenovationslist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyroomslist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.propertyroomslist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.belongsTo(models.propertytypelist, {foreignKey: 'PropertyCategory'});
        activepropertylist.hasMany(models.recreationdescriptionlist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.recreationdescriptionlist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.roomtypelist, {foreignKey: 'EANHotelID'});
        activepropertylist.hasMany(models.roomtypelist_ar_sa, {foreignKey: 'EANHotelID'});
        activepropertylist.belongsTo(models.parentregionlist, {foreignKey: 'RegionID'});
      }
    }
  });

  return activepropertylist;
};
