/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('propertytypelist_ar_sa', {
    PropertyCategory: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyCategoryDesc: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'propertytypelist_ar_sa',
    freezeTableName: true
  });
};
