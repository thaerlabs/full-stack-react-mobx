/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('attributelist_ar_sa', {
    AttributeID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      references: {
        model: 'attributelist',
        key: 'AttributeID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    AttributeDesc: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'attributelist_ar_sa',
    freezeTableName: true
  });
};
