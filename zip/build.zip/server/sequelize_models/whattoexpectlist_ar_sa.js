/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('whattoexpectlist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    WhatToExpect: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'whattoexpectlist_ar_sa',
    freezeTableName: true
  });
};
