/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('neighborhoodcoordinateslist', {
    RegionID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'parentregionlist',
        key: 'RegionID'
      }
    },
    RegionName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Coordinates: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'neighborhoodcoordinateslist',
    freezeTableName: true
  });
};
