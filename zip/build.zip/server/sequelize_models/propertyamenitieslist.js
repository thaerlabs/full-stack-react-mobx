/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertyamenitieslist = sequelize.define('propertyamenitieslist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyAmenitiesDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertyamenitieslist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertyamenitieslist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertyamenitieslist;
};
