/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var roomtypelist_ar_sa = sequelize.define('roomtypelist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    RoomTypeID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RoomTypeName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RoomTypeDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'roomtypelist_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        roomtypelist_ar_sa.belongsTo(models.roomtypelist_ar_sa, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return roomtypelist_ar_sa;
};
