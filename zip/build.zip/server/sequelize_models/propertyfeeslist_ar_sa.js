/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertyfeeslist_ar_sa = sequelize.define('propertyfeeslist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyFeesDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertyfeeslist_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertyfeeslist_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });
  
  return propertyfeeslist_ar_sa;
};
