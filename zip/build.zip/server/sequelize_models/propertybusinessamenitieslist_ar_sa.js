/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertybusinessamenitieslist_ar_sa = sequelize.define('propertybusinessamenitieslist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyBusinessAmenitiesDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertybusinessamenitieslist_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertybusinessamenitieslist_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertybusinessamenitieslist_ar_sa;
};
