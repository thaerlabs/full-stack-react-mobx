/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pointsofinterestcoordinateslist', {
    RegionID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'parentregionlist',
        key: 'RegionID'
      }
    },
    RegionName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RegionNameLong: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: '',
      primaryKey: true
    },
    Latitude: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    Longitude: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    SubClassification: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'pointsofinterestcoordinateslist',
    freezeTableName: true
  });
};
