/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertylocationlist_ar_sa = sequelize.define('propertylocationlist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyLocationDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertylocationlist_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertylocationlist_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertylocationlist_ar_sa;
};
