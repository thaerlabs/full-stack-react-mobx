/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('whattoexpectlist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    WhatToExpect: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'whattoexpectlist',
    freezeTableName: true
  });
};
