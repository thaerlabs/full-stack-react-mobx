/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertybusinessamenitieslist = sequelize.define('propertybusinessamenitieslist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyBusinessAmenitiesDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertybusinessamenitieslist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertybusinessamenitieslist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertybusinessamenitieslist;
};
