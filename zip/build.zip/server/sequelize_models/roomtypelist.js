/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var roomtypelist = sequelize.define('roomtypelist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    RoomTypeID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RoomTypeImage: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RoomTypeName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RoomTypeDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'roomtypelist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        roomtypelist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });
  
  return roomtypelist;
};
