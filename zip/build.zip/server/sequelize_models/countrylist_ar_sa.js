/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('countrylist_ar_sa', {
    CountryID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'countrylist',
        key: 'CountryID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CountryName: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'countrylist_ar_sa',
    freezeTableName: true
  });
};
