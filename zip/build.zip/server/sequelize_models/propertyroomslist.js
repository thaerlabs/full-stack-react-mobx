/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertyroomslist = sequelize.define('propertyroomslist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyRoomsDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertyroomslist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertyroomslist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertyroomslist;
};
