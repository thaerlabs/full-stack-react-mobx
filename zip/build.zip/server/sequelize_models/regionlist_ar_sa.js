/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('regionlist_ar_sa', {
    RegionID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'parentregionlist',
        key: 'RegionID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RegionName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RegionNameLong: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'regionlist_ar_sa',
    freezeTableName: true
  });
};
