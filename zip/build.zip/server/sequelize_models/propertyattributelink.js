/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertyattributelink = sequelize.define('propertyattributelink', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    AttributeID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'attributelist',
        key: 'AttributeID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    AppendTxt: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'propertyattributelink',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertyattributelink.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertyattributelink;
};
