/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var policydescriptionlist = sequelize.define('policydescriptionlist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PolicyDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'policydescriptionlist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        policydescriptionlist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return policydescriptionlist;
};
