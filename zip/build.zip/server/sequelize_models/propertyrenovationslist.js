/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertyrenovationslist = sequelize.define('propertyrenovationslist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyRenovationsDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertyrenovationslist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertyrenovationslist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });
  
  return propertyrenovationslist;
};
