/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('aliasregionlist_ar_sa', {
    RegionID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'parentregionlist',
        key: 'RegionID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    AliasString: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'aliasregionlist_ar_sa',
    freezeTableName: true
  });
};
