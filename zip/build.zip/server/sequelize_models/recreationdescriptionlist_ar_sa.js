/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var recreationdescriptionlist_ar_sa = sequelize.define('recreationdescriptionlist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RecreationDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'recreationdescriptionlist_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        recreationdescriptionlist_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return recreationdescriptionlist_ar_sa;
};
