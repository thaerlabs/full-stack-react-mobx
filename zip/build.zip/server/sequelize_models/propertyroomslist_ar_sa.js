/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertyroomslist_ar_sa = sequelize.define('propertyroomslist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyRoomsDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertyroomslist_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertyroomslist_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertyroomslist_ar_sa;
};
