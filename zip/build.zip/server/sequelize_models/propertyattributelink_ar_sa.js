/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertyattributelink_ar_sa = sequelize.define('propertyattributelink_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    AttributeID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'attributelist',
        key: 'AttributeID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    AppendTxt: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'propertyattributelink_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertyattributelink_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertyattributelink_ar_sa;
};
