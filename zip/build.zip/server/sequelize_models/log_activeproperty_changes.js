/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('log_activeproperty_changes', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    FieldName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    FieldType: {
      type: DataTypes.STRING,
      allowNull: true
    },
    FieldValueOld: {
      type: DataTypes.STRING,
      allowNull: true
    },
    FieldValueNew: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'log_activeproperty_changes',
    freezeTableName: true
  });
};
