/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var diningdescriptionlist_ar_sa = sequelize.define('diningdescriptionlist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    DiningDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'diningdescriptionlist_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function(models) {
        diningdescriptionlist_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return diningdescriptionlist_ar_sa;
};
