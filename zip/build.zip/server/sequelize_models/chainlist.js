/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var chainlist = sequelize.define('chainlist', {
    ChainCodeID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    ChainName: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'chainlist',
    freezeTableName: true,
    classMethods: {
      associate: function(models) {
        chainlist.hasMany(models.activepropertylist, {foreignKey: 'ChainCodeID'})
      }
    }
  });

  return chainlist;
};
