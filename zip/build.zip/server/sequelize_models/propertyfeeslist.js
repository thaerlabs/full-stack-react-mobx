/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertyfeeslist = sequelize.define('propertyfeeslist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyFeesDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertyfeeslist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertyfeeslist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertyfeeslist;
};
