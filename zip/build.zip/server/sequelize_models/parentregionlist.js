/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var parentregionlist = sequelize.define('parentregionlist', {
    RegionID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    RegionType: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RelativeSignificance: {
      type: DataTypes.STRING,
      allowNull: true
    },
    SubClass: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RegionName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    RegionNameLong: {
      type: DataTypes.STRING,
      allowNull: true
    },
    ParentRegionID: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    ParentRegionType: {
      type: DataTypes.STRING,
      allowNull: true
    },
    ParentRegionName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    ParentRegionNameLong: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'parentregionlist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        parentregionlist.hasOne(models.activepropertylist, {foreignKey: 'RegionID'})
      }
    }
  });
  
  return parentregionlist;
};
