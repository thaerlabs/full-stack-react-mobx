/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var  activepropertybusinessmodel = sequelize.define('activepropertybusinessmodel', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    SequenceNumber: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    Name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Address1: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Address2: {
      type: DataTypes.STRING,
      allowNull: true
    },
    City: {
      type: DataTypes.STRING,
      allowNull: true
    },
    StateProvince: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PostalCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Country: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Latitude: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    Longitude: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    AirportCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyCategory: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    PropertyCurrency: {
      type: DataTypes.STRING,
      allowNull: true
    },
    StarRating: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    Confidence: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    SupplierType: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Location: {
      type: DataTypes.STRING,
      allowNull: true
    },
    ChainCodeID: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    RegionID: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    HighRate: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    LowRate: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    CheckInTime: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CheckOutTime: {
      type: DataTypes.STRING,
      allowNull: true
    },
    BusinessModelMask: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    }
  }, {
    tableName: 'activepropertybusinessmodel',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        activepropertybusinessmodel.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return activepropertybusinessmodel;
};
