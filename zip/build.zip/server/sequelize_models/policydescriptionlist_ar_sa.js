/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var policydescriptionlist_ar_sa = sequelize.define('policydescriptionlist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PolicyDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'policydescriptionlist_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        policydescriptionlist_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return policydescriptionlist_ar_sa;
};
