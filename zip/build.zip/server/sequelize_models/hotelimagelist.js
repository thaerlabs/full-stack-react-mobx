/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var hotelimagelist = sequelize.define('hotelimagelist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    Caption: {
      type: DataTypes.STRING,
      allowNull: true
    },
    URL: {
      type: DataTypes.STRING,
      allowNull: false,
      primaryKey: true
    },
    Width: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    Height: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    ByteSize: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    ThumbnailURL: {
      type: DataTypes.STRING,
      allowNull: true
    },
    DefaultImage: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    }
  }, {
    tableName: 'hotelimagelist',
    freezeTableName: true,
    classMethods: {
      associate: function(models) {
        hotelimagelist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return hotelimagelist;
};
