/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertynationalratingslist = sequelize.define('propertynationalratingslist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyNationalRatingsDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertynationalratingslist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertynationalratingslist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertynationalratingslist;
};
