/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('attributelist', {
    AttributeID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    AttributeDesc: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Type: {
      type: DataTypes.STRING,
      allowNull: true
    },
    SubType: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'attributelist',
    freezeTableName: true
  });
};
