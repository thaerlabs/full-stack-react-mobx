/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('countrylist', {
    CountryID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CountryName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CountryCode: {
      type: DataTypes.STRING,
      allowNull: false
    },
    Transliteration: {
      type: DataTypes.STRING,
      allowNull: true
    },
    ContinentID: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'parentregionlist',
        key: 'RegionID'
      }
    }
  }, {
    tableName: 'countrylist',
    freezeTableName: true
  });
};
