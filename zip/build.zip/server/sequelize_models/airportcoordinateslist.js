/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('airportcoordinateslist', {
    AirportID: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    AirportCode: {
      type: DataTypes.STRING,
      allowNull: false,
      primaryKey: true
    },
    AirportName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Latitude: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    Longitude: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    MainCityID: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'parentregionlist',
        key: 'RegionID'
      }
    },
    CountryCode: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'airportcoordinateslist',
    freezeTableName: true
  });
};
