/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertymandatoryfeeslist = sequelize.define('propertymandatoryfeeslist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyMandatoryFeesDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertymandatoryfeeslist',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertymandatoryfeeslist.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertymandatoryfeeslist;
};
