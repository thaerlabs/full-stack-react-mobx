/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var activepropertybusinessmodel_ar_sa = sequelize.define('activepropertybusinessmodel_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Location: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CheckInTime: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CheckOutTime: {
      type: DataTypes.STRING,
      allowNull: true
    },
    BusinessModelMask: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    }
  }, {
    tableName: 'activepropertybusinessmodel_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function(models) {
        activepropertybusinessmodel_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return activepropertybusinessmodel_ar_sa;
};
