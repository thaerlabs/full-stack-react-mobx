/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('spadescriptionlist', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    SpaDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'spadescriptionlist',
    freezeTableName: true
  });
};
