/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  var propertyamenitieslist_ar_sa = sequelize.define('propertyamenitieslist_ar_sa', {
    EANHotelID: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'activepropertylist',
        key: 'EANHotelID'
      }
    },
    LanguageCode: {
      type: DataTypes.STRING,
      allowNull: true
    },
    PropertyAmenitiesDescription: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'propertyamenitieslist_ar_sa',
    freezeTableName: true,
    classMethods: {
      associate: function (models) {
        propertyamenitieslist_ar_sa.belongsTo(models.activepropertylist, {foreignKey: 'EANHotelID'})
      }
    }
  });

  return propertyamenitieslist_ar_sa;
};
