import mongoose from 'mongoose';
var Schema = mongoose.Schema;

var MenuItemSchema = new Schema({
  name: String,
  path: String
}, {collection: 'hotel_pim_menu_item', timestamps: true});

module.exports = mongoose.model('MenuItem', MenuItemSchema);
