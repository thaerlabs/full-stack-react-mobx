import mongoose from "mongoose";
var Schema = mongoose.Schema;

var HotelDraftSchema = new Schema({
  EANHotelID: Number,
  hotel_en: {},
  hotel_ar: {}
}, {
  strict: false,
  timestamps: true,
  collection: 'hotel_pim_hotels_draft'
});

module.exports = mongoose.model('Hotel_Draft', HotelDraftSchema);
