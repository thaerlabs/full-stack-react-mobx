import mongoose from "mongoose";
var Schema = mongoose.Schema;

var HotelPublishSchema = new Schema({
  EANHotelID: Number,
  hotel_en: {},
  hotel_ar: {},
  version: {type: Number, default: 1},
  versionDoc: [{ type: Schema.Types.ObjectId, ref: 'Hotel_Archive',  index: true }],
  is_synced: {type: Boolean, default: false}
}, {
  strict: false,
  timestamps: true,
  collection: 'hotel_pim_hotels_published'
});

module.exports = mongoose.model('Hotel_Published', HotelPublishSchema);
