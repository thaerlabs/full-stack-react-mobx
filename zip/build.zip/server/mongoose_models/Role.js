import mongoose from 'mongoose';
var Schema = mongoose.Schema;

var RoleSchema = new Schema({
  name: String,
  menuItems: [{ type: Schema.Types.ObjectId, ref: 'MenuItem',  index: true }]
}, {collection: 'hotel_pim_role', timestamps: true});

module.exports = mongoose.model('Role', RoleSchema);
