import mongoose from "mongoose";
var Schema = mongoose.Schema;

var HotelPublishSchema = new Schema({
  EANHotelID: Number,
  hotel_en: {},
  hotel_ar: {},
  version: {type: Number, default: 1},
  is_synced: {type: Boolean, default: false}
}, {
  strict: true,
  timestamps: true,
  collection: 'hotel_pim_hotels_archive'
});

module.exports = mongoose.model('Hotel_Archive', HotelPublishSchema);
