/**
 * Main application routes
 */

'use strict';
import { Router } from 'express';
import path from 'path';
import multer from 'multer';

const router = Router();

const imgPath = path.join(process.cwd(), 'client/assets/images');
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, imgPath);
  },
  filename: function (req, file, cb) {
    cb(null, `${file.fieldname}-${Date.now()}.${file.originalname}`);
  }
});
const upload = multer({storage});

/**
 * /api/ routes
 */
router.use('/api/', require('./api'));

router.put('/upload/image', upload.single('image'), (req, res, next) => {
  res.json({
    path: `/assets/images/${req.file.filename}`
  });
});

/**
 * render client/index.ejs
 */
router.get('/*', function(req, res) {
  res.render('index');
});

module.exports = router;
