import MenuItem from '../mongoose_models/Menu_Item';
import Role from '../mongoose_models/Role';
import User from '../mongoose_models/User';
import bluebird from 'bluebird';

export function init(){
  bluebird.coroutine(function *() {
    /**
     * Initializing menu items
     */
    yield MenuItem.remove({});
    var userMenuItem = yield new MenuItem({name: 'User Management', path: '/admin/users'}).save();
    var hotelMenuItem = yield new MenuItem({name: 'Hotel Management', path: '/admin/hotels'}).save();

    /**
     * Initializing roles
     */
    yield Role.remove({});
    var adminRole = yield new Role({name: 'admin', menuItems: [userMenuItem._id, hotelMenuItem._id]}).save();
    var userRole = yield new Role({name: 'user', menuItems: [hotelMenuItem._id]}).save();

    /**
     * Initializing users
     */
    yield User.remove({});
    yield new User({username: 'admin', password: 'admin123', passwordConfirmation: 'admin123', role: adminRole._id}).save();
    yield new User({username: 'user', password: 'user123', passwordConfirmation: 'user123', role: userRole._id}).save();

    console.log("Seeding completed");

  })().catch((err) => {
    console.log(err);
  });
}

